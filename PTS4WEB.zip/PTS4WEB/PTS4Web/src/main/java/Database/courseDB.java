/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.CourseModel;
import Models.CourseModel.Location;
import Models.MainCourse;
import Models.Semester;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sander
 */
public class courseDB extends Database
{
    public CourseModel getById(int id)
    {
        CourseModel course;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM COURSE WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            course = new CourseModel(rs.getInt("ID"), rs.getString("COURSE_CODE"), Location.valueOf(rs.getString("LOCATION")));
            statement.close();
            closeConnection();
            return course;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public MainCourse getMainCourseById(int id) {
        MainCourse course;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM MAIN_COURSE WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            rs.next();
            course = new MainCourse(rs.getInt("ID"), rs.getString("COURSE_CODE"), rs.getInt("SEMESTER_NUMBER"), rs.getString("INFO"), rs.getInt("HOURS"), rs.getString("CHANGES"));
            statement.close();
            closeConnection();
            return course;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<CourseModel> getCourses(String semesterName)
    {
        CourseModel course;
        PreparedStatement statement;
        ArrayList<CourseModel> courses = new ArrayList<>();
        try {
            openConnection();
            String sql = "SELECT c.ID, c.COURSE_CODE, c.LOCATION, c.TEACHER_ID FROM COURSE c, SEMESTER s WHERE s.id = c.semester_id AND s.SEMESTER_NAME = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, semesterName);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                course = new CourseModel(rs.getInt("ID"), rs.getString("COURSE_CODE"));
                String location = rs.getString("LOCATION");
                if(location != null) {
                    course.setLocation(Location.valueOf(location));
                }
                course.setTeacherId(rs.getInt("TEACHER_ID"));
                courses.add(course);
            }
            statement.close();
            closeConnection();
            return courses;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<CourseModel> getAllCourses()
    {
        CourseModel course;
        PreparedStatement statement;
        ArrayList<CourseModel> courses = new ArrayList<>();
        try {
            openConnection();
            String sql = "SELECT * FROM COURSE";
            statement = conn.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                course = new CourseModel(rs.getInt("ID"), rs.getInt("MAIN_COURSE_ID"), rs.getString("COURSE_CODE"), rs.getInt("TEACHER_ID"), rs.getInt("SEMESTER_ID"), rs.getInt("CLASS_ID"));
                String location = rs.getString("LOCATION");
                if(location != null) {
                    course.setLocation(Location.valueOf(location));
                }
                courses.add(course);
            }
            statement.close();
            closeConnection();
            return courses;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<CourseModel> getAllBySemester(int semesterId)
    {
        CourseModel course;
        PreparedStatement statement;
        ArrayList<CourseModel> courses = new ArrayList<>();
        try {
            openConnection();
            String sql = "SELECT * FROM COURSE WHERE SEMESTER_ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, semesterId);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                course = new CourseModel(rs.getInt("ID"), rs.getInt("MAIN_COURSE_ID"), rs.getString("COURSE_CODE"), rs.getInt("TEACHER_ID"), rs.getInt("SEMESTER_ID"), rs.getInt("CLASS_ID"));
                String location = rs.getString("LOCATION");
                if(location != null) {
                    course.setLocation(Location.valueOf(location));
                }
                courses.add(course);
            }
            statement.close();
            closeConnection();
            return courses;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<MainCourse> getMainCoursesBySemesterNumber(int semesterNumber)
    {
        if(semesterNumber <= 0) {
            return getMainCourses();
        }
        MainCourse course;
        PreparedStatement statement;
        ArrayList<MainCourse> courses = new ArrayList<>();
        try {
            openConnection();
            String sql = "SELECT * FROM MAIN_COURSE WHERE SEMESTER_NUMBER = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, semesterNumber);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                course = new MainCourse(rs.getInt("ID"), rs.getString("COURSE_CODE"), rs.getInt("SEMESTER_NUMBER"), rs.getString("INFO"), rs.getInt("HOURS"), rs.getString("CHANGES"));
                courses.add(course);
            }
            statement.close();
            closeConnection();
            return courses;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public boolean createCourse(String code, String location){
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "INSERT INTO COURSE (CLASS_ID, MAIN_COURSE_ID, COURSE_CODE, LOCATION) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, 1);
            statement.setInt(2, 1);
            statement.setString(3, code);
            statement.setString(4, location);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean updateCourse(String code, String location){
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "UPDATE course SET COURSE_CODE = ?, LOCATION = ? WHERE COURSE_CODE = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, code);
            statement.setString(2, location);
            statement.setString(3, code);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean deleteCourse(String code)
    {
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "DELETE FROM course WHERE COURSE_CODE = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, code);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ArrayList<MainCourse> getMainCourses()
    {
        MainCourse course;
        PreparedStatement statement;
        ArrayList<MainCourse> mainCourses = new ArrayList<>();
        try {
            openConnection();
            String sql = "SELECT ID, COURSE_CODE, SEMESTER_NUMBER, INFO, HOURS, CHANGES FROM MAIN_COURSE";
            statement = conn.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                course = new MainCourse(rs.getInt("ID"), rs.getString("COURSE_CODE"), rs.getInt("SEMESTER_NUMBER"), rs.getString("INFO"), rs.getInt("HOURS"), rs.getString("CHANGES"));
                mainCourses.add(course);
            }
            statement.close();
            closeConnection();
            return mainCourses;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public boolean createMainCourse(String code, String info, int hours, int semester){
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "INSERT INTO MAIN_COURSE (COURSE_CODE, SEMESTER_NUMBER, INFO, HOURS) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, code);
            statement.setInt(2, semester);
            statement.setString(3, info);
            statement.setInt(4, hours);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    /**
     * 
     * @param courseId
     * @param teacherId The ID of the teacher. 
     * A teacherId of 0 means that no teacher has been assigned.
     * @return 
     */
    public boolean linkTeacherCourse(int courseId, int teacherId) {
        PreparedStatement statement;
        try {
            if(courseId < 1 || teacherId < 0) {
                return false;
            }
            openConnection();
            String sql = "UPDATE COURSE SET TEACHER_ID = ? WHERE ID = ?";
            statement = conn.prepareStatement(sql);   
            if (teacherId == 0) {
                statement.setNull(1, java.sql.Types.NULL);
            } else {
                statement.setInt(1, teacherId);
            }
            statement.setInt(2, courseId);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ArrayList<Semester> getAllSemesters(){
        ArrayList<Semester> semesters = new ArrayList<>();
        Semester semester;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM SEMESTER";
            statement = conn.prepareStatement(sql);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    semester = new Semester(rs.getInt("ID"), rs.getString("SEMESTER_NAME"));
                    semesters.add(semester);
                }
                statement.close();
            }
            closeConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return semesters;
    }
}
