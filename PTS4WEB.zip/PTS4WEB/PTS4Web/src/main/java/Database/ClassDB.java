package Database;

import Models.ClassModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yorrin
 */
public class ClassDB extends Database {
    
    private final SemesterDB semesterDB;
    
    public ClassDB() {
        semesterDB = new SemesterDB();
    }
    
    public ClassModel getById(int id){
        ClassModel classModel = null;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM CLASS WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if(rs.next()) {
                    classModel = new ClassModel(rs.getInt("ID"), rs.getString("CLASS_CODE"), rs.getInt("SEMESTER_ID"), rs.getInt("SEMESTER_NUMBER"));
                }
                statement.close();
            }
            closeConnection();
            if(classModel != null) {
               classModel.setSemesterName(semesterDB.getById(classModel.getSemesterId()).getName());
            }
            return classModel;
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<ClassModel> getAllBySemester(int semesterId) {
        ArrayList<ClassModel> classes = new ArrayList<>();
        ClassModel classModel;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM CLASS WHERE SEMESTER_ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, semesterId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    classModel = new ClassModel(rs.getInt("ID"), rs.getString("CLASS_CODE"), rs.getInt("SEMESTER_ID"), rs.getInt("SEMESTER_NUMBER"));
                    classes.add(classModel);
                }
                statement.close();
            }
            closeConnection();
            for(ClassModel c : classes) {
                c.setSemesterName(semesterDB.getById(c.getSemesterId()).getName());
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return classes;
    }
    
    public ArrayList<ClassModel> getAll(){
        ArrayList<ClassModel> classes = new ArrayList<>();
        ClassModel classModel;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM CLASS";
            statement = conn.prepareStatement(sql);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    classModel = new ClassModel(rs.getInt("ID"), rs.getString("CLASS_CODE"), rs.getInt("SEMESTER_ID"), rs.getInt("SEMESTER_NUMBER"));
                    classes.add(classModel);
                }
                statement.close();
            }
            closeConnection();
            for(ClassModel c : classes) {
                c.setSemesterName(semesterDB.getById(c.getSemesterId()).getName());
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return classes;
    }
    
    public boolean createClass(String code, int semesterId, int semesterNumber){
        PreparedStatement statement;
        try {
            if(code.equals("") || semesterId < 1) {
                return false;
            }
            openConnection();
            String sql = "INSERT INTO CLASS (CLASS_CODE, SEMESTER_ID, SEMESTER_NUMBER) VALUES (?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, code);
            statement.setInt(2, semesterId);
            statement.setInt(3, semesterNumber);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
    
    public boolean addCourseToClass(ClassModel classModel, int mainCourseId, String courseCode) {
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "INSERT INTO COURSE (CLASS_ID, MAIN_COURSE_ID, COURSE_CODE, SEMESTER_ID) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, classModel.getId());
            statement.setInt(2, mainCourseId);
            statement.setString(3, courseCode);
            statement.setInt(4, classModel.getSemesterId());
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
