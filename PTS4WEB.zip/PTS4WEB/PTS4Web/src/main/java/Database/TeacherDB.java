package Database;

import Models.Registration;
import Models.Teacher;
import Models.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yorrin
 */
public class TeacherDB extends Database
{

    private final UserDB userDB = new UserDB();
    private final courseDB courseDB = new courseDB();
    private final SemesterDB semesterDB = new SemesterDB();

    public Teacher getById(int id)
    {
        Teacher teacher;
        PreparedStatement statement = null;
        try
        {
            openConnection();
            String sql = "SELECT * FROM TEACHER WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            rs.next();
            teacher = new Teacher(rs.getInt("ID"), rs.getInt("HOURS"), rs.getString("PREFERRED_LOCATION"), rs.getString("NAME"), rs.getString("SURNAME"), rs.getString("PHONE_NUMBER"));
            statement.close();
            closeConnection();
            return teacher;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public Teacher getByName(String name)
    {
        Teacher teacher;
        PreparedStatement statement = null;
        try
        {
            openConnection();
            String sql = "SELECT T.ID, T.HOURS, T.PREFERRED_LOCATION, T.NAME, T.SURNAME, T.PHONE_NUMBER FROM TEACHER T, USERTABLE U WHERE U.EMAIL = ? AND T.ID = U.TEACHER_ID";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            ResultSet rs = statement.executeQuery();
            rs.next();
            teacher = new Teacher(
                    rs.getInt("ID"),
                    rs.getInt("HOURS"),
                    rs.getString("PREFERRED_LOCATION"),
                    rs.getString("NAME"),
                    rs.getString("SURNAME"),
                    rs.getString("PHONE_NUMBER"));
            statement.close();
            closeConnection();
            System.out.println(teacher);
            return teacher;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public Teacher getTeacherByName(String name, String surname){
        Teacher teacher = null;
        PreparedStatement statement = null;
        try
        {
            openConnection();

            String sql = "SELECT * FROM TEACHER WHERE NAME = ? AND SURNAME = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, surname);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                teacher = new Teacher(rs.getInt("ID"), rs.getInt("HOURS"), rs.getString("PREFERRED_LOCATION"), rs.getString("NAME"), rs.getString("SURNAME"), rs.getString("PHONE_NUMBER"));
            }
            statement.close();
            closeConnection();

            return teacher;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    //Get a list of all teachers from the database
    public ArrayList<Teacher> getTeachers()
    {
        Teacher teacher;
        PreparedStatement statement = null;
        ArrayList<Teacher> teachers = new ArrayList<>();
        try
        {
            openConnection();

            String sql = "SELECT * FROM TEACHER";

            statement = conn.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                teacher = new Teacher(rs.getInt("ID"), rs.getInt("HOURS"), rs.getString("PREFERRED_LOCATION"), rs.getString("NAME"), rs.getString("SURNAME"), rs.getString("PHONE_NUMBER"));
                teachers.add(teacher);
            }
            statement.close();
            closeConnection();
            for (User u : userDB.getUsers())
            {
                if (u.getTeacherId() > 0)
                {
                    teachers.stream().filter(t -> t.getId() == u.getTeacherId()).findFirst().get().setEmail(u.getEmail());
                }
            }
            return teachers;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public boolean insertTeacher(Teacher teacher){
        PreparedStatement statement;
        try
        {
            openConnection();

            String sql = "INSERT INTO TEACHER (NAME, SURNAME, PHONE_NUMBER) VALUES (?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, teacher.getName());
            statement.setString(2, teacher.getSurname());
            statement.setString(3, teacher.getPhoneNumber());
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean registerTeacher(String course, String email, int prio, String motivation, int semesterId)
    {
        PreparedStatement statement;
        int courseID = 0;
        int teacherID = 0;
        try
        {
            openConnection();

            String sql = "SELECT ID, SEMESTER_NUMBER FROM MAIN_COURSE WHERE COURSE_CODE = ?";

            statement = conn.prepareStatement(sql);
            statement.setString(1, course);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                courseID = rs.getInt("ID");
            }

            sql = "SELECT TEACHER_ID FROM USERTABLE WHERE EMAIL = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, email);
            rs = statement.executeQuery();
            while (rs.next())
            {
                teacherID = rs.getInt("TEACHER_ID");
            }

            sql = "SELECT * FROM COURSE_REGISTRATION WHERE MAIN_COURSE_ID = ? AND TEACHER_ID = ? AND SEMESTER_ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, courseID);
            statement.setInt(2,teacherID);
            statement.setInt(3, semesterId);
            rs = statement.executeQuery();
            rs.next();
            if (!rs.first()) {
                rs.close();
                sql = "INSERT INTO COURSE_REGISTRATION (MAIN_COURSE_ID, TEACHER_ID, SEMESTER_ID, PRIORITY, MOTIVATION) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE PRIORITY = ? , MOTIVATION = ? ";
                statement = conn.prepareStatement(sql);
                statement.setInt(1, courseID);
                statement.setInt(2, teacherID);
                statement.setInt(3, semesterId);
                statement.setInt(4, prio);
                statement.setString(5, motivation);
                statement.setInt(6, prio);
                statement.setString(7, motivation);
                statement.execute();
                statement.close();
            } else {
                sql = "UPDATE COURSE_REGISTRATION SET PRIORITY = ?, MOTIVATION = ? WHERE MAIN_COURSE_ID = ? AND TEACHER_ID = ? AND SEMESTER_ID = ?";
                statement = conn.prepareStatement(sql);
                statement.setInt(1, prio);
                statement.setString(2, motivation);
                statement.setInt(3, courseID);
                statement.setInt(4, teacherID);
                statement.setInt(5, semesterId);
                statement.execute();
                statement.close();
            }
            
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public int getRegisteredHours(String name)
    {
        int hours = 0;
        PreparedStatement statement = null;
        try
        {
            openConnection();
            String sql = "SELECT M.HOURS FROM TEACHER T, USERTABLE U, COURSE_REGISTRATION C, MAIN_COURSE M WHERE U.EMAIL = ? AND T.ID = U.TEACHER_ID AND T.ID = C.TEACHER_ID AND C.MAIN_COURSE_ID = M.ID";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                hours += rs.getInt("HOURS");
            }
            statement.close();
            closeConnection();
            return hours;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
    public ArrayList<Registration> getRegistrationsTeacher(int teacherId) {
        ArrayList<Registration> registrations = new ArrayList<>();
        PreparedStatement statement = null;
        try
        {
            openConnection();
            String sql = "SELECT * FROM COURSE_REGISTRATION WHERE TEACHER_ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, teacherId);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                registrations.add(new Registration(rs.getInt("ID"), rs.getInt("PRIORITY"), rs.getString("MOTIVATION"), rs.getInt("MAIN_COURSE_ID"), rs.getInt("SEMESTER_ID")));
            }
            statement.close();
            closeConnection();
            
            for(Registration r : registrations) {
                r.setMainCourse(courseDB.getMainCourseById(r.getMainCourseId()));
                r.setSemester(semesterDB.getById(r.getSemesterId()));
            }
            return registrations;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<String> getRegisteredCourses(String name)
    {
        ArrayList<String> courses = new ArrayList<>();
        PreparedStatement statement = null;
        try
        {
            openConnection();
            String sql = "SELECT M.COURSE_CODE FROM TEACHER T, USERTABLE U, COURSE_REGISTRATION C, MAIN_COURSE M WHERE U.EMAIL = ? AND T.ID = U.TEACHER_ID AND T.ID = C.TEACHER_ID AND C.MAIN_COURSE_ID = M.ID";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                courses.add(rs.getString("COURSE_CODE"));
            }
            statement.close();
            closeConnection();
            return courses;
        } catch (SQLException ex)
        {
            Logger.getLogger(TeacherDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public boolean deleteTeacher(int id)
    {
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "DELETE FROM Teacher WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            
            //tostring????
            statement.setString(1, Integer.toString(id));
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
