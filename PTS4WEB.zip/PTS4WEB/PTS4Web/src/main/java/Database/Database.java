/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Frank
 */
public class Database
{

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://studmysql01.fhict.local:3306/dbi310878";
    static final String USER = "dbi310878";
    static final String PASS = "Iie72-HD";
    Connection conn = null;
    Statement stmt = null;

    public Database()
    {
    }

    public boolean openConnection()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            return true;
        } 
            catch(Exception e){
            System.out.println(e);
            return false;
    }

    }

    public boolean closeConnection() throws SQLException
    {
        try
        {
            conn.close();
            return true;
        } catch (Exception e)
        {
            System.out.println(e);
            return false;
        }
    }
}
