/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.Registration;
import Models.Semester;
import Models.Teacher;
import Models.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Frank
 */
public class OverviewDB extends Database{
    
    private final courseDB courseDB = new courseDB();
    private final TeacherDB teacherDB = new TeacherDB();
    private final SemesterDB semesterDB = new SemesterDB();
    
    public ArrayList<Registration> getAll() {
        ArrayList<Registration> registrations = new ArrayList<>();
        int mainCourseId = 0;
        int teacherId = 0;
        int semesterId = 0;
        Registration registration;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM COURSE_REGISTRATION";
            statement = conn.prepareStatement(sql);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    registration = new Registration(rs.getInt("id"), rs.getInt("PRIORITY"), rs.getString("MOTIVATION"));
                    registration.setTeacherId(rs.getInt("TEACHER_ID"));
                    registration.setMainCourseId(rs.getInt("MAIN_COURSE_ID"));
                    registration.setSemesterId(rs.getInt("SEMESTER_ID"));
                    registrations.add(registration);
                }
                statement.close();
            }
            closeConnection();
            
            for(Registration r : registrations) {
                r.setMainCourse(courseDB.getMainCourseById(r.getMainCourseId()));
                r.setTeacher(teacherDB.getById(r.getTeacherId()));
                r.setSemester(semesterDB.getById(r.getSemesterId()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return registrations;
    }

    public ArrayList<Registration> getByPeriod(int semesterId) {
        ArrayList<Registration> registrations = new ArrayList<>();
        Registration registration;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM COURSE_REGISTRATION WHERE SEMESTER_ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, semesterId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    registration = new Registration(rs.getInt("id"), rs.getInt("PRIORITY"), rs.getString("MOTIVATION"));
                    registration.setMainCourseId(rs.getInt("MAIN_COURSE_ID"));
                    registration.setTeacherId(rs.getInt("TEACHER_ID"));
                    registrations.add(registration);
                }
                statement.close();
            }
            closeConnection();
            
            for(Registration r : registrations) {
                r.setMainCourse(courseDB.getMainCourseById(r.getMainCourseId()));
                r.setTeacher(teacherDB.getById(r.getTeacherId()));
                r.setSemester(semesterDB.getById(semesterId));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return registrations;
    }
}