package Database;

import Models.Semester;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yorrin
 */
public class SemesterDB extends Database
{

    public Semester getById(int id)
    {
        Semester semester = null;
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "SELECT * FROM SEMESTER WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery())
            {
                if (rs.next())
                {
                    semester = new Semester(rs.getInt("ID"), rs.getString("SEMESTER_NAME"), rs.getBoolean("ACTIEF"));
                }
                statement.close();
            }
            closeConnection();
            return semester;
        } catch (SQLException ex)
        {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public ArrayList<Semester> getAllActive()
    {
        ArrayList<Semester> semesters = new ArrayList<>();
        Semester semester;
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "SELECT * FROM SEMESTER WHERE ACTIEF = 1";
            statement = conn.prepareStatement(sql);
            try (ResultSet rs = statement.executeQuery())
            {
                while (rs.next())
                {
                    semester = new Semester(rs.getInt("ID"), rs.getString("SEMESTER_NAME"), rs.getBoolean("ACTIEF"));
                    semesters.add(semester);
                }
                statement.close();
            }
            closeConnection();
        } catch (SQLException ex)
        {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return semesters;
    }

    public boolean updateSemester(String name, Boolean active, int id)
    {
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "UPDATE SEMESTER SET SEMESTER_NAME = ?, ACTIEF = ? WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setBoolean(2, active);
            statement.setInt(3, id);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(SemesterDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean deleteSemester(String name)
    {
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "DELETE FROM SEMESTER WHERE SEMESTER_NAME = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(SemesterDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public ArrayList<Semester> getAll()
    {
        ArrayList<Semester> semesters = new ArrayList<>();
        Semester semester;
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "SELECT * FROM SEMESTER";
            statement = conn.prepareStatement(sql);
            try (ResultSet rs = statement.executeQuery())
            {
                while (rs.next())
                {
                    semester = new Semester(rs.getInt("ID"), rs.getString("SEMESTER_NAME"), rs.getBoolean("ACTIEF"));
                    semesters.add(semester);
                }
                statement.close();
            }
            closeConnection();
        } catch (SQLException ex)
        {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return semesters;
    }

    // Add a new semester to the database
    public boolean addSemester(String semesterName)
    {
        PreparedStatement statement;
        try
        {
            openConnection();
            String sql = "INSERT INTO SEMESTER (SEMESTER_NAME, ACTIEF) VALUES (?, 1)";
            statement = conn.prepareStatement(sql);

            statement.setString(1, semesterName);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
