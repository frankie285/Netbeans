/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Models.User;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Frank
 */
public class UserDB extends Database{
    
    public List<User> getUsers() throws SQLException{
        User user = null;
        this.openConnection();
        try{
            stmt = conn.createStatement();
            String sql = "SELECT * from usertable";
            ResultSet rs = stmt.executeQuery(sql);
            
            List<User> users = new ArrayList();
            while(rs.next()){
          
            int id  = rs.getInt("ID");
            String email = rs.getString("EMAIL");
            String password = rs.getString("USERPASSWORD");
            String role = rs.getString("ROLE");

            user = new User(id, email, password, role);
            user.setTeacherId(rs.getInt("TEACHER_ID"));
            users.add(user);
            }
            rs.close();
            stmt.close();
            this.closeConnection();
            return users;
        }
        catch(Exception e){
            System.out.println(e);
            this.closeConnection();
            return null;
        }
    }
    
    public boolean insertUser(User user, int teacherID){
        PreparedStatement statement;
        try
        {
            openConnection();

            String sql = "INSERT INTO USERTABLE (EMAIL, USERPASSWORD, ROLE, TEACHER_ID) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, user.getEmail());
            statement.setString(2, user.getPassword());
            statement.setString(3, user.getRole());
            statement.setInt(4, teacherID);
            statement.execute();
            statement.close();
            closeConnection();
            return true;
        } catch (SQLException ex)
        {
            Logger.getLogger(courseDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public User getById(int id){
        User user = null;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM USERTABLE WHERE ID = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if(rs.next()) {
                    user = new User(rs.getInt("ID"), rs.getString("EMAIL"), rs.getString("USERPASSWORD"), rs.getString("ROLE"));
                    user.setTeacherId(rs.getInt("TEACHER_ID"));
                }
                statement.close();
            }
            return user;
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public User logIn(String email, String password){
        User user = null;
        PreparedStatement statement;
        try {
            openConnection();
            String sql = "SELECT * FROM USERTABLE WHERE EMAIL = ? AND USERPASSWORD = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);
            try (ResultSet rs = statement.executeQuery()) {
                if(rs.next()) {
                    user = new User(rs.getInt("ID"), rs.getString("EMAIL"), rs.getString("USERPASSWORD"), rs.getString("ROLE"));
                    user.setTeacherId(rs.getInt("TEACHER_ID"));
                }
                statement.close();
            }
            return user;
        } catch (SQLException ex) {
            Logger.getLogger(ClassDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
