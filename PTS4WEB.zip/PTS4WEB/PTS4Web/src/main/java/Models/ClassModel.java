package Models;

/**
 *
 * @author Yorrin
 */
public class ClassModel implements Comparable<ClassModel> {
    private int id;
    private String code;
    private int semesterId;
    private String semesterName;
    private int semesterNumber;
    
    public ClassModel() {
        
    }
    
    public ClassModel(int id, String code, int semesterId, int semesterNumber) {
        this.id = id;
        this.code = code;
        this.semesterId = semesterId;
        this.semesterNumber = semesterNumber;
        semesterName = "";
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public int getSemesterId() {
        return semesterId;
    }
    
    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }
    
    public String getSemesterName() {
        return semesterName;
    }

    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }
    
    public int getSemesterNumber() {
        return semesterNumber;
    }

    public void setSemesterNumber(int semesterNumber) {
        this.semesterNumber = semesterNumber;
    }
    
    @Override
    public String toString(){
        return "Code: " + code + "\nSemester : " + semesterName;
    }

    @Override
    public int compareTo(ClassModel o) {
        return semesterName.compareTo(o.semesterName);
    }
    
}
