/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.io.Serializable;

/**
 *
 * @author Frank
 */
public class User implements Serializable {
    
    private int ID;
    private String Email;
    private String Password;
    private String Role;
    private int teacherId;
    
    public User(){
        
    }
    
    public User(String email, String password, String role){
        this.Email = email;
        this.Password = password;
        this.Role = role;
    }
    
    public User(int id, String email, String password, String role){
        this.ID = id;
        this.Email = email;
        this.Password = password;
        this.Role = role;
    }

    public void setID(int id){
        this.ID = id;        
    }
    
    public int getID(){
        return this.ID;
    }
    
    public void setEmail(String email){
        this.Email = email;
    }
    
    public String getEmail(){
        return this.Email;
    }
    
    public void setPassword(String password){
        this.Password = password;
    }
    
    public String getPassword(){
        return this.Password;
    }
    
    public void setRole(String role){
        this.Role = role;
    }
    
    public String getRole(){
        return this.Role;
    }
    
        public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }
}