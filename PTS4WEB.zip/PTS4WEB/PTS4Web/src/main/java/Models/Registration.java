/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author HPuser
 */
public class Registration implements Comparable {
    private int id;
    private MainCourse mainCourse;
    private int mainCourseId;
    private Teacher teacher;
    private int teacherId;
    private Semester semester;
    private int semesterId;
    private int priority;
    private String motivation;

    public Registration() {
    }

    public Registration(int id, int priority, String motivation) {
        this.id = id;
        this.priority = priority;
        this.motivation = motivation;
    }

    public Registration(int id, MainCourse mainCourse, Teacher teacher, Semester semester, int priority) {
        this.id = id;
        this.mainCourse = mainCourse;
        this.teacher = teacher;
        this.semester = semester;
        this.priority = priority;
    }

    public Registration(int id, int priority, String motivation, int mainCourseId, int semesterId) {
        this.id = id;
        this.priority = priority;
        this.motivation = motivation;
        this.mainCourseId = mainCourseId;
        this.semesterId = semesterId;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public int getMainCourseId() {
        return mainCourseId;
    }

    public void setMainCourseId(int mainCourseId) {
        this.mainCourseId = mainCourseId;
    }

    public int getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }
    
    public MainCourse getMainCourse() {
        return mainCourse;
    }

    public void setMainCourse(MainCourse mainCourse) {
        this.mainCourse = mainCourse;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = semester;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getMotivation() {
        return motivation;
    }

    public void setMotivation(String motivation) {
        this.motivation = motivation;
    }
      
    @Override
    public String toString() {
        return "ID: " + id + "\n MAIN_COURSE: " + mainCourse.getCourseCode() + "\n TEACHER: " + teacher.getFullName() + "\n MOTIVATION: " + motivation;
    }

    @Override
    public int compareTo(Object o) {
        return Integer.compare(priority, ((Registration)o).getPriority());
    }
    
}
