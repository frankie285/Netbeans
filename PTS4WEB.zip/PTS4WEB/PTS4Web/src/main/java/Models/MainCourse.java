package Models;

/**
 *
 * @author Yorrin
 */
public class MainCourse {
    
    private int id;
    private String courseCode;
    private int semesterNumber;
    private String info;
    private int hours;
    private String changes;
    
    public MainCourse() {
        
    }

    public MainCourse(int id, String courseCode, int semesterNumber, String info, int hours, String changes) {
        this.id = id;
        this.courseCode = courseCode;
        this.semesterNumber = semesterNumber;
        this.info = info;
        this.hours = hours;
        this.changes = changes;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getSemesterNumber() {
        return semesterNumber;
    }

    public void setSemesterNumber(int semesterNumber) {
        this.semesterNumber = semesterNumber;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public String getChanges() {
        return changes;
    }

    public void setChanges(String changes) {
        this.changes = changes;
    }
    
    public String ToString()
    {
        return courseCode;
    }
}
