/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Sander
 */
public class CourseModel
{

    private int id;
    private int mainCourseId;
    private String courseCode;
    private Location location;
    private int teacherId;
    private Semester semester;
    private int semesterId;
    private int classId;
    
    /**
     *
     * @param id
     * @param courseCode
     * @param location
     */
    public CourseModel(int id, String courseCode, Location location) {
        this.id = id;
        this.courseCode = courseCode;
        this.location = location;
    }

    public CourseModel(int id, String courseCode) {
        this.id = id;
        this.courseCode = courseCode;
    }
    
    /**
     *
     * @param id
     * @param courseCode
     * @param location
     * @param semester
     */
    public CourseModel(int id, String courseCode, Location location, Semester semester)
    {
        this.id = id;
        this.courseCode = courseCode;
        this.location = location;
        this.semester = semester;
    }

    public CourseModel(int id, int mainCourseId, String courseCode, int teacherId, int semesterId, int classId) {
        this.id = id;
        this.mainCourseId = mainCourseId;
        this.courseCode = courseCode;
        this.teacherId = teacherId;
        this.semesterId = semesterId;
        this.classId = classId;
    }
    
    
    
    public CourseModel()
    {
        
    }  

    /**
     * @return the id
     */
    public int getId()
    {
        return id;
    }
    
    public void setId(int id)
    {
        this.id = id;
    }

    public int getMainCourseId() {
        return mainCourseId;
    }

    public void setMainCourseId(int mainCourseId) {
        this.mainCourseId = mainCourseId;
    } 

    /**
     * @return the courseCode
     */
    public String getCourseCode()
    {
        return courseCode;
    }

    /**
     * @param courseCode the courseCode to set
     */
    public void setCourseCode(String courseCode)
    {
        this.courseCode = courseCode;
    }

    /**
     * @return the location
     */
    public Location getLocation()
    {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(Location location)
    {
        this.location = location;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }
    
    @Override
    public String toString(){
        return "ID: " + id + "\nCode: " + courseCode;
    }

    /**
     * @return the semester
     */
    public Semester getSemester()
    {
        return semester;
    }

    /**
     * @param semester the semester to set
     */
    public void setSemester(Semester semester)
    {
        this.semester = semester;
    }

    public int getSemesterId() {
        return semesterId;
    }

    public void setSemesterId(int semesterId) {
        this.semesterId = semesterId;
    }

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }
    
    
       
    /**
     *  enum with the 2 different locations
     */
    public enum Location
    {
        EINDHOVEN,
        TILBURG
    }
}
