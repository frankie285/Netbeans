package Models;

/**
 *
 * @author Yorrin
 */
public class Teacher {
    private int id;
    private int hours;
    private String preferredLocation;
    private String email;
    private String name;
    private String surname;
    private String phoneNumber;
    
    public Teacher() {
        
    }
    
    public Teacher(int id, int hours, String preferredLocation, String name, String surname, String phoneNumber) {
        this.id = id;
        this.hours = hours;
        this.preferredLocation = preferredLocation;
        this.name = name;
        this.surname = surname;
        this.phoneNumber = phoneNumber;
    }
    
    public Teacher(String name, String surname, String phoneNumber){
        this.name = name;
        this.surname = surname;
        this.phoneNumber = phoneNumber;
    }
    
    public String getFullName() {
        if(name == null || name.equals("null")) {
            return email;
        }
        return name + " " + surname;
    }
    
    public int getId() {
        return id;
    }
    
    public int getHours() {
        return hours;
    }
    
    public void setTeacher(Teacher teacher){
        this.id = teacher.id;
        this.email = teacher.email;
        this.hours = teacher.hours;
        this.name = teacher.name;
        this.phoneNumber = teacher.phoneNumber;
        this.preferredLocation = teacher.preferredLocation;
        this.surname = teacher.surname;
    }
    
    public void setHours(int hours) {
        this.hours = hours;
    }
    
    public String getPreferredLocation() {
        return preferredLocation;
    }
    
    public void setPreferredLocation(String preferredLocation) {
        this.preferredLocation = preferredLocation;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name == null ? "" : name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the surName
     */
    public String getSurname()
    {
        return surname == null ? "" : surname;
    }

    /**
     * @param surName the surName to set
     */
    public void setSurname(String surname)
    {
        this.surname = surname;
    }

    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
}
