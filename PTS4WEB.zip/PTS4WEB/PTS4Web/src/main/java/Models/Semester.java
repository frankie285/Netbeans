/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author kevin
 */
public class Semester 
{
    private int id;
    private String name;
    private Boolean active;
    
    public Semester(int id, String name, Boolean active) {
        this.id = id;
        this.name = name;
        this.active = active;
    }
    
    public Semester(int id, String name) {
        this.id = id;
        this.name = name;
        
    }
    
    public Semester(String name)
    {
        this.name = name;
     
        
    }
    
    public Semester(){
            
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return name;
    }

    /**
     * @return the active
     */
    public Boolean getActive()
    {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(Boolean active)
    {
        this.active = active;
    }
    
}
