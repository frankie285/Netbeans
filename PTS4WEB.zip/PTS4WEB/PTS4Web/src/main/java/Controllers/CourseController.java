/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Database.ClassDB;
import Database.OverviewDB;
import Database.SemesterDB;
import Database.TeacherDB;
import Database.courseDB;
import Models.ClassModel;
import org.springframework.stereotype.Controller;
import Models.CourseModel;
import Models.MainCourse;
import Models.Registration;
import Models.Semester;
import Models.Teacher;
import Models.User;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;
import javax.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author Sander
 */
@Controller
@RequestMapping("course")
public class CourseController
{

    private final courseDB courseDB = new courseDB();
    private final TeacherDB teacherDB = new TeacherDB();
    private final ClassDB classDB = new ClassDB();
    private final SemesterDB semesterDB = new SemesterDB();
    private final OverviewDB overviewDB = new OverviewDB();
    
    @RequestMapping(method = RequestMethod.GET)
    public String home(ModelMap model)
    {
        ArrayList<Semester> semesters = courseDB.getAllSemesters();
        model.put("semesters", semesters);
        return "course";
    }
    
    @RequestMapping(value = "Info")
    public String info(ModelMap model, HttpSession session)
    {
        if(session.getAttribute("user") == null) {
            return "error/unauthorized";
        }
        ArrayList<MainCourse> mainCourses = courseDB.getMainCourses();
        model.put("mainCourses", mainCourses);
        System.out.println(mainCourses);
        return "courseInfo";
    }
    
    @RequestMapping(value = "Info", method = RequestMethod.POST)
    public String filteredInfo(ModelMap model, HttpSession session, @RequestParam int semesterNumber){
        
        ArrayList<MainCourse> mainCourses;
        if(semesterNumber <= 0) {
            mainCourses = courseDB.getMainCourses();
        } else {
            mainCourses = courseDB.getMainCoursesBySemesterNumber(semesterNumber);
        }   
        
        ArrayList<Semester> semesters = semesterDB.getAll();
        model.put("semesters", semesters);
        model.put("mainCourses", mainCourses);
        model.put("semesterNumber", semesterNumber);
        return "courseInfo";
    }
    
    @RequestMapping(value = "Overview", method = RequestMethod.POST)
    public String overview(ModelMap model, @RequestParam String semesterName)
    {
        System.out.println(semesterName);
        ArrayList<CourseModel> courses = courseDB.getCourses(semesterName);
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        model.put("courses", courses);
        model.put("teachers", teachers);
        return "courseOverview";
    }

    @RequestMapping(value = "Overview", method = RequestMethod.GET)
    public String course(ModelMap model, String semesterName)
    {
        
        ArrayList<CourseModel> courses = courseDB.getCourses(semesterName);
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        model.put("courses", courses);
        model.put("teachers", teachers);
        System.out.println(courses);
        System.out.println(teachers);
        System.out.println(model.isEmpty());
        return "courseOverview";
    }
    
    @RequestMapping(value = "summary", method = RequestMethod.GET)
    public String summary(ModelMap model, HttpSession session) {
        
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<ClassModel> classes = classDB.getAll();
        ArrayList<CourseModel> courses = courseDB.getAllCourses();
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        ArrayList<Semester> semesters = semesterDB.getAll();
        ArrayList<Registration> registrations = overviewDB.getAll();
        Collections.sort(registrations);
        model.put("registrations", registrations);
        model.put("semesters", semesters);
        model.put("teachers", teachers);
        model.put("classes", classes);
        model.put("courses", courses);
        return "coursesummary";
    }
    
    @RequestMapping(value = "summary", method = RequestMethod.POST)
    public String summaryForSemester(ModelMap model, @RequestParam int semesterId, @RequestParam int semesterNumber, HttpSession session) {
        
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<ClassModel> classes;
        if(semesterId <= 0) {
            classes = classDB.getAll();
        } else {
            classes = classDB.getAllBySemester(semesterId);
        }   
        
        if(semesterNumber > 0) {
            classes = (ArrayList<ClassModel>)classes.stream().filter(c -> c.getSemesterNumber() == semesterNumber).collect(Collectors.toList());
        }
        ArrayList<CourseModel> courses = courseDB.getAllCourses();
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        ArrayList<Semester> semesters = semesterDB.getAll();  
        ArrayList<Registration> registrations = overviewDB.getAll();
        Collections.sort(registrations);
        model.put("registrations", registrations);
        model.put("semesters", semesters);
        model.put("teachers", teachers);
        model.put("classes", classes);
        model.put("courses", courses);
        model.put("selectedSemester", semesterId);
        model.put("semesterNumber", semesterNumber);
        return "coursesummary";
    }
    
    @RequestMapping(value = "linkteacher", method = RequestMethod.POST)
    public String linkTeacher(ModelMap model, @ModelAttribute("courseModel") CourseModel courseModel, @RequestParam int teacherId, @RequestParam int semesterIdYo, @RequestParam int semesterNumberYo, HttpSession session) {
        
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        courseDB.linkTeacherCourse(courseModel.getId(), teacherId);
        ArrayList<ClassModel> classes;
        if(semesterIdYo <= 0) {
            classes = classDB.getAll();
        } else {
            classes = classDB.getAllBySemester(semesterIdYo);
        }   
        
        if(semesterNumberYo > 0) {
            classes = (ArrayList<ClassModel>)classes.stream().filter(c -> c.getSemesterNumber() == semesterNumberYo).collect(Collectors.toList());
        }
        
        ArrayList<CourseModel> courses = courseDB.getAllCourses();
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        ArrayList<Semester> semesters = semesterDB.getAll();
        ArrayList<Registration> registrations = overviewDB.getAll();
        model.put("registrations", registrations);
        model.put("semesters", semesters);
        model.put("teachers", teachers);
        model.put("classes", classes);
        model.put("courses", courses);
        model.put("selectedSemester", semesterIdYo);
        model.put("semesterNumber", semesterNumberYo);
        return "coursesummary";
    }
    
    @RequestMapping(value = "courseDelete", method = RequestMethod.POST)
    public String courseDelete(ModelMap model)
    {
        System.out.println("schrik");
        ArrayList<CourseModel> courses = courseDB.getAllCourses();
        model.put("courses", courses);
        return "courseDelete";
    }
    
    @RequestMapping(value = "courseDelete", method = RequestMethod.GET)
    public String courseDeleteGet(ModelMap model)
    {
        ArrayList<CourseModel> courses = courseDB.getAllCourses();
        model.put("courses", courses);
        return "courseDelete";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String updateCourse(@ModelAttribute("courseModel") CourseModel courseModel, HttpSession session)
    {
        System.out.println("upupupupupupup");
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        if (courseDB.updateCourse(courseModel.getCourseCode(), courseModel.getLocation().toString())
            && courseDB.linkTeacherCourse(courseModel.getId(), courseModel.getTeacherId()))
        {
            return "redirect:/course.htm";
        } else
        {
            System.out.println("failed");
            return "course";
        }
    }
    
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public String deleteCourse(@ModelAttribute("courseModel") CourseModel courseModel, HttpSession session)
    {
        System.out.println("DELDELDELDL");
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        if (courseDB.deleteCourse(courseModel.getCourseCode()))
        {
            return "redirect:/course.htm";
        } else
        {
            
            System.out.println("failed");
            return "course";
        }
    }

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String create(Model model, HttpSession session)
    {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        model.addAttribute("courseModel", new CourseModel());
        return "courseCreate";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String createCourse(@ModelAttribute("MainCourse") MainCourse mainCourse, HttpSession session)
    {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        if (courseDB.createMainCourse(mainCourse.getCourseCode(), mainCourse.getInfo(), mainCourse.getHours(), mainCourse.getSemesterNumber()))
        {
            return "create";
        }
        return "course";
    }
}
