/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Database.OverviewDB;
import Database.SemesterDB;
import Database.courseDB;
import Models.MainCourse;
import Models.Registration;
import Models.Semester;
import Models.User;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Frank
 */

@Controller
public class OverviewController {
    OverviewDB ov = new OverviewDB();
    courseDB courseDB = new courseDB();
    SemesterDB semesterDB = new SemesterDB();
    
    @RequestMapping(value = "/overview", method = RequestMethod.GET)
    public String overview(ModelMap model, HttpSession session) throws SQLException {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<Registration> registrations = ov.getAll();
        Collections.sort(registrations);
        ArrayList<MainCourse> mainCourses = courseDB.getMainCourses();
        ArrayList<Semester> semesters = semesterDB.getAll();
        model.put("semesters", semesters);
        model.put("courses", mainCourses);
        model.put("registrations", registrations);
        model.put("selectedSemester", 1);
        return "overview";
    }
    
    @RequestMapping(value = "/overview", method = RequestMethod.POST)
    public String filteredOverview(ModelMap model, HttpSession session, @RequestParam int semesterId, @RequestParam int semesterNumber) throws SQLException {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<Registration> registrations;
        if(semesterId <= 0) {
            registrations = ov.getAll();
        } else {
            registrations = ov.getByPeriod(semesterId);
        } 
        if(semesterNumber > 0) {
            registrations = (ArrayList<Registration>)registrations.stream().filter(r -> r.getMainCourse().getSemesterNumber() == semesterNumber).collect(Collectors.toList());
        }
        Collections.sort(registrations);
        ArrayList<MainCourse> mainCourses = courseDB.getMainCoursesBySemesterNumber(semesterNumber);
        ArrayList<Semester> semesters = semesterDB.getAll();
        model.put("semesters", semesters);
        model.put("courses", mainCourses);
        model.put("registrations", registrations);
        model.put("selectedSemester", semesterId);
        model.put("semesterNumber", semesterNumber);
        return "overview";
    }
    
}
