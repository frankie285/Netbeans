/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Database.SemesterDB;
import Models.ClassModel;
import Models.CourseModel;
import Models.Semester;
import Models.User;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Kevin
 */
@Controller
@RequestMapping("/semester")
public class SemesterController
{

    private final SemesterDB semesterDB = new SemesterDB();

    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String create(Model model, HttpSession session)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
            return "error/unauthorized";
        }
        model.addAttribute("msg", "Give Semester Name and amount of classes!");
        return "semesterCreate";
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    public ModelAndView create(Model model, @ModelAttribute("semester") Semester semester, HttpSession session) throws SQLException
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
           return new ModelAndView("redirect:/error/unauthorized.htm");
        }
        SemesterDB sb = new SemesterDB();
        //Retrieve a semester list to check which semesters already exist.
        List<Semester> semesters = sb.getAll();
        boolean exists = false;
        if (semester.getName().equals(""))
        {
            model.addAttribute("error", "Give the name of the Semester you want to create!");
        } else
        {
            for (Semester sem : semesters)
            {
                if (semester.getName().equals(sem.getName()))
                {
                    exists = true;
                }
            }
            if (exists == false)
            {
                sb.addSemester(semester.getName());
            } else
            {
                model.addAttribute("error", "This semester already exists!");
                return new ModelAndView("redirect:/semester/create.htm");
            }
        }
        return new ModelAndView("redirect:/semester/overview.htm");
    }

    @RequestMapping(value = "overview", method = RequestMethod.GET)
    public String overview(ModelMap model, HttpSession session)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
            return "error/unauthorized";
        }
        model.put("semesters", semesterDB.getAll());
        return "semesterOverview";
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public String updateOverview(@ModelAttribute("semester") Semester semester, HttpSession session)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
            return "error/unauthorized";
        } else
        {
            SemesterDB sb = new SemesterDB();
            if(semester.getActive() == null)
            {
                semester.setActive(Boolean.FALSE);
            }
            else
            {
                semester.setActive(Boolean.TRUE);
            }
            boolean success = sb.updateSemester(semester.getName(), semester.getActive(), semester.getId() );
            if (success)
            {
                return "redirect:/semester/overview.htm";
            } else
            {
                System.out.println("failed");
                return "redirect:/semester/overview.htm";
            }
        }
    }

    @RequestMapping(value = "delete", method = RequestMethod.POST)
    public String deleteOverview(@ModelAttribute("semester") Semester semester, HttpSession session)
    {
        System.out.println("DELDELDELDL");
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
            return "error/unauthorized";
        }
        SemesterDB sb = new SemesterDB();
        boolean success = sb.deleteSemester(semester.getName());
        if (success)
        {
            return "redirect:/semester/overview.htm";
        } else
        {

            System.out.println("failed");
            return "redirect:/semester/overview.htm";
        }
    }
}
