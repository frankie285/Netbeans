/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Database.UserDB;
import Mail.Mail;
import Models.User;
import java.sql.SQLException;
import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Frank
 */
@Controller
public class LoginController {
    
     @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView login(Model model){  
        model.addAttribute("msg", "Please Enter Your Login Credentials");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
        //return "login";
    }
    
    @RequestMapping(method = RequestMethod.POST)
    public String submit(Model model, @ModelAttribute("user") User user, HttpSession session) throws SQLException, MessagingException {        
        if (user.getEmail() != null && user.getPassword() != null) {
            UserDB db = new UserDB();
            User loggedInUser = db.logIn(user.getEmail(), user.getPassword());
            if (loggedInUser != null) {
                session.setAttribute("user", loggedInUser);
                if (loggedInUser.getRole().equals("COORDINATOR")) {
                    return ("home");
                }
                if (loggedInUser.getRole().equals("TEACHER")) {
                    return ("teacherhome");
                } else {
                    return "home";
                }
            } else {
                model.addAttribute("error", "The Email / Password combination is incorrect");
                return "login";
            }
        } else {
            model.addAttribute("error", "Please fill in both fields");
            return "login";
        }
    }
    
    @RequestMapping(value = "/login/logout", method = RequestMethod.GET)
    public String logout(HttpSession session){  
        session.setAttribute("user", null);
        return "login";
    }
}
