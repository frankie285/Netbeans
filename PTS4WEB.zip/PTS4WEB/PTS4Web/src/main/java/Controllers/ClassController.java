package Controllers;

import Database.ClassDB;
import Database.SemesterDB;
import Database.courseDB;
import Models.ClassModel;
import Models.CourseModel;
import Models.MainCourse;
import Models.User;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Yorrin
 */

@Controller
@RequestMapping("class")
public class ClassController {
    
    private final ClassDB classDB = new ClassDB();
    private final SemesterDB semesterDB = new SemesterDB();
    private final courseDB courseDB = new courseDB();
    
        @RequestMapping()
    public String home(HttpSession session) {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        return "class";
    }
    
    @RequestMapping("overview")
    public String overview(ModelMap model, HttpSession session) {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<ClassModel> classes = classDB.getAll();
        Collections.sort(classes);
        model.put("classes", classes);
        model.put("semesters", semesterDB.getAll());
        return "classoverview";
    }
    
    @RequestMapping(value = "overview", method = RequestMethod.POST)
    public String overview(ModelMap model, @RequestParam int semesterId, HttpSession session){
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        ArrayList<ClassModel> classes = classDB.getAllBySemester(semesterId);
        Collections.sort(classes);
        model.put("classes", classes);
        model.put("semesters", semesterDB.getAll());
        return "classoverview";
    }
    
    @RequestMapping(value = "create", method = RequestMethod.GET)
    public String create(ModelMap model, HttpSession session){
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        model.put("semesters", semesterDB.getAll());
        return "classcreate";
    }
    
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public String createClass(@ModelAttribute("classModel") ClassModel classModel, Model model, HttpSession session) {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        if(classModel.getCode().equals("")) {
            model.addAttribute("semesters", semesterDB.getAll());
            model.addAttribute("error", "Semester code can not be empty.");
            return "classcreate";
        } else if (classDB.createClass(classModel.getCode(), classModel.getSemesterId(), classModel.getSemesterNumber())) {       
            return "redirect:overview.htm";
        } else {
            model.addAttribute("semesters", semesterDB.getAll());
            model.addAttribute("error", "Error inserting the value into the database.\nThis could be caused by trying to insert a duplicate value.");
            return "classcreate";
        }
    }
    
    @RequestMapping(value = "addcourse", method = RequestMethod.GET)
    public String addCourseGet(Model model, HttpSession session) {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        
        List<ClassModel> classes = classDB.getAll();
        List<MainCourse> courses = courseDB.getMainCourses();
        model.addAttribute("courses" , courses);
        model.addAttribute("classes", classes);
        return "addcourse";
    }
    
    @RequestMapping(value = "addcourse", method = RequestMethod.POST)
    public String addCourse(Model model, HttpSession session, @RequestParam int classId, @RequestParam int courseId, @RequestParam String courseCode) {
        if(session.getAttribute("user") == null || !((User)session.getAttribute("user")).getRole().equals("COORDINATOR")) {
            return "error/unauthorized";
        }
        
        if(classId > 0 && courseId > 0 && !courseCode.equals("")) {
            ClassModel classModel = classDB.getById(classId);
            if(!classDB.addCourseToClass(classModel, courseId, courseCode)) {
                model.addAttribute("error", "Error adding course to the database");
            } 
        } else {
            model.addAttribute("error", "Please pick a class and a course and fill in a course code");
        }
        
        List<ClassModel> classes = classDB.getAll();
        List<MainCourse> courses = courseDB.getMainCourses();
        model.addAttribute("selectedClassId", classId);
        model.addAttribute("courses" , courses);
        model.addAttribute("classes", classes);
        return "addcourse";
    }
}
