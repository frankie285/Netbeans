/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Database.SemesterDB;
import Database.TeacherDB;
import Database.UserDB;
import Database.courseDB;
import Mail.Mail;
import Models.MainCourse;
import Models.Registration;
import Models.Semester;
import Models.Teacher;
import Models.User;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author kevin
 */
@Controller
@RequestMapping("/teacher")
public class TeacherController
{

    private final TeacherDB teacherDB = new TeacherDB();
    private final courseDB coursesDB = new courseDB();
    private final SemesterDB semesterDB = new SemesterDB();

    @RequestMapping()
    public String home(HttpServletRequest request, HttpSession session)
    {
        if (session.getAttribute("user") == null)
        {
            return "error/unauthorized";
        }
        if (request.getParameter("lang") != null)
        {
            System.out.println(request.getParameter("lang"));
            session.setAttribute("language", request.getParameter("lang"));
        } else
        {
            session.setAttribute("language", "nl");
        }
        return "teacherhome";
    }

    @RequestMapping("/overview")
    public String teacherOverview(ModelMap model, HttpSession session)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("COORDINATOR"))
        {
            return "error/unauthorized";
        }
        ArrayList<Teacher> teachers = teacherDB.getTeachers();
        Collections.sort(teachers, new Comparator<Teacher>()
        {
            @Override
            public int compare(Teacher o1, Teacher o2)
            {
                return o1.getSurname().compareTo(o2.getSurname());
            }
        });
        model.put("teachers", teachers);
        return "teacherOverview";
    }

    @RequestMapping(value = "sendEmail", method = RequestMethod.POST)
    public String sendEmail(Model model, @ModelAttribute("teacher") Teacher teacher, HttpSession session) throws SQLException, MessagingException
    {
        if (teacher.getEmail() == null)
        {
            return "teacherOverview";
        } else
        {
            UserDB db = new UserDB();
            List<User> users = db.getUsers();
            for (User user : users)
            {
                if (user.getEmail().equals(teacher.getEmail()))
                {
                    Mail email = new Mail();
                    email.generateAndSendEmail(user.getEmail(), "Dear " + user.getEmail() + ", your password is: " + user.getPassword() + " kind regards, PTS4Web.");
                }
            }
            return "redirect:/teacher/overview.htm";
        }
    }

    @RequestMapping(value = "registration", method = RequestMethod.GET)
    public String teacherRegistration(ModelMap model, HttpSession session)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("TEACHER"))
        {
            return "error/unauthorized";
        }
        int hours = teacherDB.getByName(((User) session.getAttribute("user")).getEmail()).getHours();
        model.put("hours", hours);
        int regHours = teacherDB.getRegisteredHours(((User) session.getAttribute("user")).getEmail());
        model.put("regHours", regHours);
        ArrayList<MainCourse> courses = coursesDB.getMainCourses();
        model.put("courses", courses);
        ArrayList<Registration> registrations = teacherDB.getRegistrationsTeacher(((User) session.getAttribute("user")).getTeacherId());
        
        Collections.sort(registrations, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return Integer.compare(((Registration) o1).getId(), ((Registration) o2).getId()) * - 1;
            }
        });
        
        model.put("registrations", registrations);
        ArrayList<Semester> semesters =  semesterDB.getAllActive();
        model.put("semesters", semesters);
        return "teacherRegistration";
    }

    @RequestMapping(value = "registration", method = RequestMethod.POST)
    public String teacherReg(ModelMap model, HttpSession session, @RequestParam int semesterId, @RequestParam String one, @RequestParam String two, @RequestParam String three, @RequestParam String four, @RequestParam String five, @RequestParam String six, @RequestParam String seven, @RequestParam String eight, @RequestParam String nine, @RequestParam String motivation)
    {
        if (session.getAttribute("user") == null || !((User) session.getAttribute("user")).getRole().equals("TEACHER"))
        {
            return "error/unauthorized";
        }
        System.out.println(one);
        System.out.println(two);
        System.out.println(three);
        if (!"empty".equals(one))
        {
            teacherDB.registerTeacher(one, ((User) session.getAttribute("user")).getEmail(), 1, motivation, semesterId);
        }
        if (!"empty".equals(two))
        {
            teacherDB.registerTeacher(two, ((User) session.getAttribute("user")).getEmail(), 2, motivation, semesterId);
        }
        if (!"empty".equals(three))
        {
            teacherDB.registerTeacher(three, ((User) session.getAttribute("user")).getEmail(), 3, motivation, semesterId);
        }
        if (!"empty".equals(four))
        {
            teacherDB.registerTeacher(four, ((User) session.getAttribute("user")).getEmail(), 4, motivation, semesterId);
        }
        if (!"empty".equals(five))
        {
            teacherDB.registerTeacher(five, ((User) session.getAttribute("user")).getEmail(), 5, motivation, semesterId);
        }
        if (!"empty".equals(six))
        {
            teacherDB.registerTeacher(six, ((User) session.getAttribute("user")).getEmail(), 6, motivation, semesterId);
        }
        if (!"empty".equals(seven))
        {
            teacherDB.registerTeacher(seven, ((User) session.getAttribute("user")).getEmail(), 7, motivation, semesterId);
        }
        if (!"empty".equals(eight))
        {
            teacherDB.registerTeacher(eight, ((User) session.getAttribute("user")).getEmail(), 8, motivation, semesterId);
        }
        if (!"empty".equals(nine))
        {
            teacherDB.registerTeacher(nine, ((User) session.getAttribute("user")).getEmail(), 9, motivation, semesterId);
        }
        return teacherRegistration(model, session);
    }
}
