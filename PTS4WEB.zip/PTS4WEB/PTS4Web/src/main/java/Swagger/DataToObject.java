/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Swagger;

import Database.TeacherDB;
import Database.UserDB;
import Models.Teacher;
import Models.User;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author Frank
 */
public class DataToObject {
    

    private TeacherDB tDb;
    private UserDB uDb;
    
    public DataToObject(){
        tDb = new TeacherDB();
        uDb = new UserDB();
    }
    
    public String JSONToString() throws FileNotFoundException, IOException{
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream("teachers.txt");
        BufferedReader buf = new BufferedReader(new InputStreamReader(is)); 
        String line = buf.readLine(); 
        StringBuilder sb = new StringBuilder(); 
        while(line != null){ 
            sb.append(line).append("\n"); 
            line = buf.readLine(); 
        } 
    
        return sb.toString(); 
    }
    
    public String StringToJSONObject(String content){
        content = '{' + " " + "\"teachers\"" + ':' + content + '}';
        return content;
    }
    
    public void JSONToDatabase(String content) throws JSONException{
         JSONObject obj = new JSONObject(content);
        JSONArray array = obj.getJSONArray("teachers");
        for(int i = 0 ; i < array.length() ; i++){
            String email = array.getJSONObject(i).getString("mail");
            String givenName = array.getJSONObject(i).getString("givenName");
            String surName =  array.getJSONObject(i).getString("surName");
            String phoneNumber = array.getJSONObject(i).getString("telephoneNumber");
            String password = getRandomPassword();
            String role = "TEACHER";
            
            User user = new User(email, password, role);
            Teacher teacher = new Teacher(givenName, surName, phoneNumber);
            
            Teacher t = tDb.getTeacherByName(teacher.getName(), teacher.getSurname());
            if(t == null){
                tDb.insertTeacher(teacher);
                Teacher insertedTeacher = tDb.getTeacherByName(teacher.getName(), teacher.getSurname());
                uDb.insertUser(user, insertedTeacher.getId());
                
            }
            
        };
    }
    
    private String getRandomPassword() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder password = new StringBuilder();
        Random rnd = new Random();
        while (password.length() < 8) { // length of the random string.
            int index = (int) (rnd.nextFloat() * characters.length());
            password.append(characters.charAt(index));
        }
        return password.toString();
    }
}
